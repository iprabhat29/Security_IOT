def test(msg,key):
	fileout = msg+key
        print fileout


test("encrypted","2")
