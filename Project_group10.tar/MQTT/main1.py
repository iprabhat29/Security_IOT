from enc_crypto import *
enc = enc("Hello Bro")
print dec(enc)
